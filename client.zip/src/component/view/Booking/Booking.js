import React from 'react'

const Booking = () => {
  return (
    <div>

    </div>
  )
}

export default Booking
